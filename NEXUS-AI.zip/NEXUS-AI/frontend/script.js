function toggleChat() {
    const chat = document.getElementById('chatWindow');
    if (chat.classList.contains('hidden')) {
        chat.classList.remove('hidden');
    } else {
        chat.classList.add('hidden');
    }
}

function sendChat() {
    const input = document.getElementById('userText');
    const display = document.getElementById('chatDisplay');
    const text = input.value.trim();

    if (text === "") return;

    const userDiv = document.createElement('div');
    userDiv.className = 'msg user';
    userDiv.innerText = text;
    display.appendChild(userDiv);
    
    input.value = "";
    display.scrollTop = display.scrollHeight;

    const thinkingDiv = document.createElement('div');
    thinkingDiv.className = 'msg bot';
    thinkingDiv.innerText = "Gemini is thinking...";
    thinkingDiv.id = "thinking";
    display.appendChild(thinkingDiv);
    display.scrollTop = display.scrollHeight;

    setTimeout(() => {
        const thinking = document.getElementById('thinking');
        if (thinking) thinking.remove();

        const botDiv = document.createElement('div');
        botDiv.className = 'msg bot';

        const lowerText = text.toLowerCase();
        if (lowerText.includes("hello") || lowerText.includes("hi")) {
            botDiv.innerText = "Hello! I am Nexus AI. How can I optimize your business today?";
        } else if (lowerText.includes("nexus") || lowerText.includes("what is")) {
            botDiv.innerText = "Nexus AI is a leading artificial intelligence firm specializing in Neural Networks and Predictive Analytics.";
        } else if (lowerText.includes("service") || lowerText.includes("offer")) {
            botDiv.innerText = "We offer 8 core services including NLP, Computer Vision, and Robotic Process Automation.";
        } else if (lowerText.includes("contact") || lowerText.includes("email")) {
            botDiv.innerText = "You can reach our team at contact@nexusai.com or use the form on the Contact page.";
        } else {
            botDiv.innerText = "That is an excellent question. Our deep learning models are designed to solve exactly that kind of complex challenge.";
        }

        display.appendChild(botDiv);
        display.scrollTop = display.scrollHeight;
    }, 1500); 
}

function toggleTheme() {
    const body = document.body;
    const btn = document.querySelector('.themeBtn');

    body.classList.toggle('lightMode');

    if (body.classList.contains('lightMode')) {
        btn.innerText = "🌙 Dark";
    } else {
        btn.innerText = "☀ Light";
    }
}